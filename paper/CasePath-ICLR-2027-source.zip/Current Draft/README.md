# CasePath manuscript

Compile `main.tex` with XeLaTeX. Overleaf handles the bibliography and cross-references.

- `frontmatter.tex`: submitted title and the revised abstract (mirror it in OpenReview).
- `sections/`: main paper and required statements, ordered by `main.tex`.
- `appendix/`: supplementary material.
- `figures/`: the original PNG illustrations and algorithm, plus eleven vector PDF plots and dataset maps. Empirical plot labels follow one naming scheme.
- `tables/`: table contents.
- `results.tex`: frozen result definitions used by the text and tables.
- `references.bib`: citations.

The two `iclr2027_conference` files are the conference template. Keep them unchanged.
Update measurements from preserved experiment evidence; do not edit result values to fit the prose. Figure-generation code and research records belong in the reproducibility release, outside this typesetting package (the accompanying figure-source archive contains the generators, frozen inputs and style checks).

Reviewer resources use an anonymous mirror and a separate offline supplement. The mirror is a fixed source snapshot; it must not redirect to an identifying site when it expires. The offline guide is a teaching example, not a benchmark result.

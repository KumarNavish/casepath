# Mobile retained-case header evidence

Source branch: `codex/mobile-case-header-20261018`.
Pushed commit: `002820d942379c0916d17407bf30df90b3ef8948`.
Exact base: `4a03578bcaecd0cc4948d36747d96ce68e905244`.
Source checkout: `/workspace/casepath-reference-85a-qa`, host `656813ef2295`.

The final regression uses the existing fully intercepted native Chromium fixture with current production renderer/controller and asset bytes, the original heating claim's full featured label, a viewport meta tag, and `isMobile:true`/touch at 320, 390 and 430 pixels. Desktop is 1428 pixels. It navigates claim → Knowledge → Cases, measures both views, then returns to the same claim's Documents view. No real network API, provider, source acquisition, application server or persistent journal is used.

`receipt.json` records versions, exact commands, hashes and final per-view geometry. `verified.tap` and `verified.exit` show 4 passed / 0 failed. `verified/` has one JSON receipt (both measured views) and one final Cases screenshot for each width. The test executed before the source commit, so its checkoutCommit is the exact base; its injected CSS and test hashes match the committed bytes.

`final-base-counterfactual.tap` and `final-base-counterfactual/` run the final unchanged test bytes against `base.css`, copied from the exact base Git object. All three mobile widths fail with document/inner width 531 and a 514.765625px return span; desktop passes. Exit is 1 as expected. This is a counterfactual, not an unresolved fixed-source failure.

Earlier failures are preserved: `before*` reproduces the original issue at 390 and 320; `after*` shows min-width/max-width plus label wrapping alone is insufficient because of the header's max-content grid tracks; `candidate-width*` shows width:100% alone also cannot resolve that intrinsic track contribution. Component-local contain:inline-size resolves it without changing the navigation tracks. Mobile controls also receive explicit 44px minimum width and height.

`after-containment*` and `final*` contain additional negative evidence: capturing a Playwright screenshot between views changes Chromium 151 pointer emulation, making the second view's coarse-pointer assertion fail even when using native taps. `final-json*` passes the identical checks without intermediate screenshots. The final test captures evidence after both measurements and retains every assertion; `verified*` passes with screenshots enabled.

Run commands are preserved in `run-focused.sh`; each invocation records its raw output and exit code. All TMPDIR/TMP/TEMP values were set to `/workspace/mch-tmp` before Node/Python/browser initialization. The managed Python version was inspected, but the final regression needs no Python helper. Existing prepared Node v24.19.0, Playwright 1.62.1 and Chromium 151.0.7922.173 were reused without installation, dependencies or lockfile changes.

Only `casepath/assets/autonomous-workspace-v1.css` and `casepath-qa/unified-product-browser-v1.test.cjs` changed. Git diff checks passed. Integration, asset query rebinding, sealing, full gates, actual Mac visual inspection and publication remain with the Mac integration owner. No environment configuration was changed. Unrelated ports 4173, 4189 and 4190 and their processes were preserved; no worker-owned runtime remains. Final disk availability exceeds 3 GiB.

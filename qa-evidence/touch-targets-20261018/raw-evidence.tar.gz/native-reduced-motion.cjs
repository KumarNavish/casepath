'use strict';
const fs = require('node:fs');
const {chromium} = require('playwright');
const launch = chromium.launch.bind(chromium);
chromium.launch = async options => {
  const browser = await launch(options), createContext = browser.newContext.bind(browser);
  browser.newContext = async options => {
    const context = await createContext({...options, reducedMotion: 'reduce'}), createPage = context.newPage.bind(context);
    context.newPage = async (...args) => {
      const page = await createPage(...args);
      const observed = await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
      if (process.env.CASEPATH_DESKTOP_MOTION_RECEIPT) fs.writeFileSync(process.env.CASEPATH_DESKTOP_MOTION_RECEIPT, JSON.stringify({requestedNativeContextOption: {reducedMotion: 'reduce'}, observedReducedMotion: observed}));
      if (!observed) throw new Error('Native reduced-motion context was not applied');
      return page;
    };
    return context;
  };
  return browser;
};

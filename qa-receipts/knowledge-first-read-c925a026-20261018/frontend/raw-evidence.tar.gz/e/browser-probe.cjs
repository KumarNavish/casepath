'use strict';
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),http=require('node:http'),path=require('node:path'),crypto=require('node:crypto');
const source='/workspace/casepath-knowledge-startup-render-20261018',out='/workspace/knowledge-first-read-20261018/frontend/e';
const projection=fs.readFileSync('/workspace/knowledge-learning-coordinator-20261016/projection-6064.json');
let assetDelay=0,responseDelay=0;
const boot=`<script>window.CASEPATH_API=window.location.origin;window.CASEPATH_HOSTED_AUTONOMOUS=true;window.CASEPATH_PUBLIC_READ_ONLY=true;window.__probe={marks:[],longtasks:[]};window.__mark=(name)=>window.__probe.marks.push({name,at:performance.now()});document.addEventListener('DOMContentLoaded',()=>__mark('DCL'));new PerformanceObserver(list=>__probe.longtasks.push(...list.getEntries().map(e=>({at:e.startTime,duration:e.duration})))).observe({type:'longtask',buffered:true});new MutationObserver(()=>{if(document.querySelector('[data-au-learning]')&&!__probe.content){__probe.content=performance.now();requestAnimationFrame(()=>{__probe.nextFrame=performance.now();});}}).observe(document,{subtree:true,childList:true});</script>`;
function instrument(script){
const originalTime="new Date(event.at).toLocaleString('en-GB',{timeZone:'UTC',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false})";
if(process.env.CACHED_DATE_FORMAT)script=script.replace('  function learningTime(event) {','  let probeFormatter; function learningTime(event) {');
const dateExpression=process.env.CACHED_DATE_FORMAT?"(probeFormatter ||= new Intl.DateTimeFormat('en-GB',{timeZone:'UTC',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false})).format(new Date(event.at))":originalTime;
script=script.replace('return '+originalTime+"+' UTC';","const probeStarted=performance.now(); const probeDate="+dateExpression+"+' UTC'; window.__probe.dateTimeCalls=(window.__probe.dateTimeCalls||0)+1; window.__probe.dateTimeMilliseconds=(window.__probe.dateTimeMilliseconds||0)+performance.now()-probeStarted; return probeDate;");
return script
.replace("  'use strict';","  'use strict'; window.__mark('workspace-factory');")
.replace("  function mount(container, options = {}) {","  function mount(container, options = {}) { window.__mark('mount-start');")
.replace("    async function persistReadCache() {","    async function persistReadCache() { window.__mark('cache-start');")
.replace("const sha256 = await digest(canonicalJSON(material));","window.__mark('cache-canonical-start'); const pendingHash=digest(canonicalJSON(material)); window.__mark('cache-sync-end'); const sha256 = await pendingHash;")
.replace("        storage.setItem(READ_CACHE_CONTRACT,JSON.stringify({...material,sha256}));","        window.__mark('cache-set-start'); storage.setItem(READ_CACHE_CONTRACT,JSON.stringify({...material,sha256})); window.__mark('cache-end');")
.replace("    function renderKnowledge(data, pin, initial = false, preference = null) {","    function renderKnowledge(data, pin, initial = false, preference = null) { window.__mark('render-start');")
.replace("cancelLearning();host.innerHTML=knowledgeMarkup(data,claims,pin,knowledgeFacet,position);","cancelLearning();window.__mark('markup-start');const probeHTML=knowledgeMarkup(data,claims,pin,knowledgeFacet,position);window.__mark('markup-end');host.innerHTML=probeHTML;window.__mark('DOM-end');")
.replace("    async function showKnowledge(writeHistory = true, pin = null, preference = null) {","    async function showKnowledge(writeHistory = true, pin = null, preference = null) { window.__mark('show-start');")
.replace("        const data = await request('/knowledge');","        window.__mark('knowledge-request'); const data = await request('/knowledge'); window.__mark('knowledge-response-parsed');")
.replace("        notice(''); reconcileKnowledge(data);","        notice(''); reconcileKnowledge(data); window.__mark('render-end');");}
const requests=[];
const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://127.0.0.1');requests.push({url:u.pathname,at:Date.now()});
 if(u.pathname.startsWith('/api/')){if(u.pathname.endsWith('/knowledge')){await new Promise(r=>setTimeout(r,responseDelay));res.writeHead(200,{'content-type':'application/json','cache-control':'no-store'});return res.end(projection);}res.writeHead(404,{'content-type':'application/json'});return res.end('{"detail":"Outside scoped read fixture"}');}
 const target=u.pathname==='/'?'/index.html':u.pathname;
 const file=path.resolve(source,'casepath','.'+target);if(!file.startsWith(source+'/casepath/')){res.writeHead(403);return res.end();}
 try{let data=fs.readFileSync(file);if(target==='/index.html')data=Buffer.from(data.toString().replace('<head>','<head>'+boot));if(target==='/assets/autonomous-workspace-v1.js'){await new Promise(r=>setTimeout(r,assetDelay));data=Buffer.from(instrument(data.toString()));}
 res.writeHead(200,{'content-type':target.endsWith('.js')?'application/javascript':target.endsWith('.html')?'text/html':target.endsWith('.css')?'text/css':target.endsWith('.json')?'application/json':'application/octet-stream','cache-control':'no-store'});res.end(data);
 }catch(error){res.writeHead(404);res.end();}
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],downloadsPath:'/workspace/knowledge-first-read-20261018/frontend/t'});
 const results=[];try{
 for(const config of process.env.PROBE_CPU_ONLY?[{cpu:4,asset:0,api:0}]:[{cpu:1,asset:0,api:0},{cpu:4,asset:0,api:0},{cpu:1,asset:400,api:0},{cpu:1,asset:400,api:1390}]){
 assetDelay=config.asset;responseDelay=config.api;const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',route=>new URL(route.request().url()).origin===`http://127.0.0.1:${port}`?route.continue():route.abort());const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:config.cpu});
 await page.goto(`http://127.0.0.1:${port}/#autonomous/knowledge`,{waitUntil:'domcontentloaded'});await page.waitForSelector('[data-au-learning]',{timeout:15000});await page.waitForTimeout(300);
 const measured=await page.evaluate(()=>({...__probe,resources:performance.getEntriesByType('resource').map(e=>({url:new URL(e.name).pathname,start:e.startTime,responseStart:e.responseStart,responseEnd:e.responseEnd,duration:e.duration})),html:document.querySelector('[data-au-view]').innerHTML.length,route:location.hash,status:document.querySelector('.au-global-status').textContent}));results.push({config,errors,...measured});await context.close();
 }
 }finally{await browser.close();server.close();}
 const receipt={sourceCommit:require('node:child_process').execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),workspaceSHA256:crypto.createHash('sha256').update(fs.readFileSync(source+'/casepath/assets/autonomous-workspace-v1.js')).digest('hex'),base:'c925a0267971edb52fea5f2bd9653a2495b7ac15',projectionBytes:projection.length,projectionSHA256:crypto.createHash('sha256').update(projection).digest('hex'),note:'Local public synthetic export, 23 derived heads. CPU and endpoint delays are controlled diagnostics, not hosted measurements.',results,requests};
 fs.writeFileSync(out+'/'+(process.argv[2]||'baseline-browser')+'.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(results.map(r=>({...r,resources:r.resources.filter(e=>/workspace-v1.js|knowledge/.test(e.url))})),null,2));
})().catch(error=>{console.error(error);server.close();process.exitCode=1;});

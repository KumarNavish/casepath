'use strict';
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'),fs=require('node:fs'),http=require('node:http'),path=require('node:path');
const source='/workspace/casepath-knowledge-startup-render-20261018',out='/workspace/knowledge-first-read-20261018/frontend/e',ui=require(source+'/casepath/assets/autonomous-workspace-v1.js');
const fixture=JSON.parse(fs.readFileSync(out+'/heating-decoded.json')),id=fixture.head.claimId,api='/api/claim-loops/v1/autonomous';
const operations=Buffer.from(fixture.operations,'base64'),opening=fixture.opening,snapshot=fixture.head_snapshot;
const full={...snapshot,mode:'replay',replay_only:true,through_seq:fixture.head.revision,provenance:{...opening.provenance}};
for(const[field,key]of [['source_roster_sha256','source_roster_sha256'],['policy_id','policy_id'],['run_id','run_id'],['event_sha256','last_event_sha256']])full.provenance[field]=full.state[key];
full.provenance.rule_pack_sha256=[...new Set((full.state.receipts||[]).map(r=>r.receipt?.rule_pack_sha256).filter(Boolean))].sort();
ui.readReplay(full,id,fixture.head.revision);
const boot=`<script>window.CASEPATH_PUBLIC_READ_ONLY=true;window.__probe={marks:[],facts:[],maps:[]};window.__mark=(name,extra)=>__probe.marks.push({name,at:performance.now(),...extra});new MutationObserver(()=>{if(!__probe.selected)return;const map=document.querySelector('[data-au-release-plan],.au-operation-stage');if(map&&!__probe.map)__probe.map={at:performance.now(),kind:map.hasAttribute('data-au-release-plan')?'release':'operation'};for(const node of document.querySelectorAll('[data-au-stage-fact]')){const key=node.dataset.auFactOperation+':'+node.dataset.auDockPhase;if(!__probe.facts.some(row=>row.key===key))__probe.facts.push({key,at:performance.now(),phase:node.dataset.auDockPhase,fact:node.dataset.auStageFact,operation:node.dataset.auFactOperation,text:node.textContent});}}).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['data-au-dock-phase']});</script>`;
function instrument(s){return s
.replace("    async function openClaim(id, writeHistory = true, preferences = {}) {","    async function openClaim(id, writeHistory = true, preferences = {}) { window.__mark('openClaim',{id,demo:preferences.demo});")
.replace("    function stopPresentation() {","    function stopPresentation() { window.__mark('stopPresentation');")
.replace("    function prepareOperationReads(session, id, token) {","    function prepareOperationReads(session, id, token) { window.__mark('prepareOperationReads',{id});")
.replace("    async function startOperations(session, token) {","    async function startOperations(session, token) { window.__mark('startOperations',{id:session.claimId});")
.replace("    async function chooseRecordedOpening(packet, session, id, token, ownership = null) {","    async function chooseRecordedOpening(packet, session, id, token, ownership = null) { window.__mark('chooseRecordedOpening',{id});")
.replace("        const verified = packet.promise ? await packet.promise : packet;","        const verified = packet.promise ? await packet.promise : packet; window.__mark('packet-ready');")
.replace("const decoded = await decodeRecordedSession(verified,id,choice.signal)","const decoded = await decodeRecordedSession(verified,id,choice.signal)")
.replace("      const owner = {controller,foreground:!quiet};","      window.__mark('request',{path}); const owner = {controller,foreground:!quiet};")
.replace("          const data = await response.json();","          const data = await response.json(); window.__mark('response-parsed',{path});")
.replace("              operationTrace.current = operation; operationTrace.inkRetired = false;","              operationTrace.current = operation; window.__mark('show-operation',{id:operation.id,kind:operation.kind}); operationTrace.inkRetired = false;")
.replace("      if (!descriptor || !eligible()) return false;","      if (!descriptor || !eligible()) { window.__mark('packet-ineligible',{view}); return false; }");}
const apiLatency=Number(process.env.API_LATENCY||0),apiRequests=[];const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://127.0.0.1');
 if(u.pathname.startsWith('/api/')){
 apiRequests.push({path:u.pathname+u.search,at:Date.now()});if(apiLatency)await new Promise(r=>setTimeout(r,apiLatency));let data;
 if(u.pathname===api+'/status')data={read_only:true,writable:false,enabled:false};
 else if(u.pathname===api+'/claims')data={claims:[{...snapshot.state,origin:'canonical_original'}]};
 else if(u.pathname===api+'/knowledge')data={versions:[],uses:[],quarantined:[]};
 else if(u.pathname===api+'/claims/'+id+'/replay')data=u.searchParams.get('through_seq')==='0'?opening:u.searchParams.get('through_seq')===String(fixture.head.revision)?full:null;
 else if(u.pathname===api+'/claims/'+id+'/snapshot')data=snapshot;
 else if(u.pathname===api+'/claims/'+id+'/operations'){res.writeHead(200,{'content-type':'application/x-ndjson'});return res.end(operations);}
 else if(u.pathname.includes('/sources/'))data=snapshot.state.acquired_sources.find(s=>u.pathname.includes('/'+s.artifact_id+'/text'));
 res.writeHead(data?200:404,{'content-type':'application/json','cache-control':'no-store'});return res.end(JSON.stringify(data||{detail:'Outside exact heating packet fixture'}));
 }
 const target=u.pathname==='/'?'/index.html':u.pathname,file=path.resolve(source,'casepath','.'+target);if(!file.startsWith(source+'/casepath/')){res.writeHead(403);return res.end();}
 try{let data=fs.readFileSync(file);if(target==='/index.html')data=Buffer.from(data.toString().replace('<head>','<head>'+boot));if(target==='/assets/autonomous-workspace-v1.js')data=Buffer.from(instrument(data.toString()));res.writeHead(200,{'content-type':target.endsWith('.js')?'application/javascript':target.endsWith('.html')?'text/html':target.endsWith('.css')?'text/css':target.endsWith('.json')?'application/json':'application/octet-stream','cache-control':'no-store'});res.end(data);}catch(e){res.writeHead(404);res.end();}
});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port,browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const results=[];
 try{for(const mode of ['direct-picker','direct-demonstration','cases-demonstration']){
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',r=>new URL(r.request().url()).origin===origin?r.continue():r.abort());
 const hash=mode==='direct-picker'?`#autonomous/claim/${id}?mode=replay&operations=recorded&collection=reference`:mode==='direct-demonstration'?'#autonomous/demonstration?operations=recorded':'#autonomous/cases';
 await page.goto(origin+'/'+hash,{waitUntil:'domcontentloaded'});
 if(mode==='direct-picker'){await page.getByRole('button',{name:'Choose case',exact:true}).waitFor();await page.getByRole('button',{name:'Choose case',exact:true}).click();await page.locator(`[data-au-demo-case="${id}"]:not([data-au-demo-saved])`).waitFor();await page.evaluate(()=>{__probe.selected=performance.now();});await page.locator(`[data-au-demo-case="${id}"]:not([data-au-demo-saved])`).click();}
 else if(mode==='cases-demonstration'){await page.locator('[data-au-claims]').waitFor();await page.waitForTimeout(200);await page.evaluate(()=>{__probe.selected=performance.now();});await page.getByRole('button',{name:'Demonstration',exact:true}).click();}
 else await page.evaluate(()=>{__probe.selected=performance.now();});
 await page.waitForFunction(()=>__probe.facts.filter(x=>x.phase==='landed').length>=8,{timeout:30000});await page.waitForTimeout(150);
 const row=await page.evaluate(()=>({...__probe,route:location.hash,status:document.querySelector('.au-global-status').textContent,current:document.querySelector('[data-au-current-operation]')?.dataset.auCurrentOperation,text:document.querySelector('[data-au-stage-fact]')?.textContent}));results.push({mode,errors,...row});console.log(JSON.stringify({mode,selected:row.selected,map:row.map&&row.map.at-row.selected,firstText:row.facts[0]?.at-row.selected,firstLanded:row.facts.find(x=>x.phase==='landed')?.at-row.selected,eighthLanded:row.facts.filter(x=>x.phase==='landed')[7]?.at-row.selected,marks:row.marks,status:row.status,errors}));await context.close();
 }}finally{await browser.close();server.close();}
 fs.writeFileSync(out+'/'+(process.argv[2]||'restart-baseline')+'.json',JSON.stringify({source:'1abbec801b0e8660ec3f0662fb8ff7ec57fddea0',packet:'exact shipped autonomous-recorded-heating-v1.json',apiLatency,results,apiRequests},null,2));
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});

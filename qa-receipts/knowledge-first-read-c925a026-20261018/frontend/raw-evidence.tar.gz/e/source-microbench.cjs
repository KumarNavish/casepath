'use strict';
const fs=require('node:fs'),{performance}=require('node:perf_hooks'),{createHash}=require('node:crypto');
const root='/workspace/casepath-knowledge-startup-render-20261018',fixture='/workspace/knowledge-learning-coordinator-20261016/projection-6064.json';
const ui=require(root+'/casepath/assets/autonomous-workspace-v1.js');
const raw=fs.readFileSync(fixture),original=JSON.parse(raw);
const samples=[];
for(let i=0;i<12;i++){
 const data=JSON.parse(raw),row={};let start=performance.now();ui.readKnowledge(data);row.readKnowledge=performance.now()-start;
 start=performance.now();JSON.stringify(data);row.knowledgeSizeJSON=performance.now()-start;
 const material={contract:'casepath.read-cache/1',api:'http://127.0.0.1/api/claim-loops/v1/autonomous',saved_at:Date.now(),snapshots:[],knowledge:{at:Date.now(),value:data}};
 start=performance.now();JSON.stringify({...material,sha256:'0'.repeat(64)});JSON.stringify({...material,sha256:'0'.repeat(64)});row.cacheSizeJSON=performance.now()-start;
 start=performance.now();const canonical=ui.canonicalJSON(material);row.cacheCanonicalJSON=performance.now()-start;
 start=performance.now();const model=ui.knowledgeLearningModel(data);row.model=performance.now()-start;
 start=performance.now();const html=ui.knowledgeMarkup(data,[],null,'process',{index:0,stage:0});row.markup=performance.now()-start;row.htmlBytes=Buffer.byteLength(html);row.events=model.events.length;
 samples.push(row);
}
const output={base:process.argv[2],fixture,bytes:raw.length,sha256:createHash('sha256').update(raw).digest('hex'),versions:original.versions.length,uses:original.uses.length,samples};
fs.writeFileSync('/workspace/knowledge-first-read-20261018/frontend/e/source-microbench.json',JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));

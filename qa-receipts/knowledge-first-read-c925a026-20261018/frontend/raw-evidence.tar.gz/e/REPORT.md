# Frontend startup and replay readiness handoff

Actual Cloud host: `656813ef2295`. Clean normal clone: `/workspace/casepath-knowledge-startup-render-20261018`.
Branch: `codex/knowledge-startup-render-20261018`.
Base: `c925a0267971edb52fea5f2bd9653a2495b7ac15`.
Pushed cumulative tip: `a83ef2acd71d6cfc47dd61337e2dd0bb6eff7c33`.

Commits, in order:

- `1abbec801b0e8660ec3f0662fb8ff7ec57fddea0`: start a selected public Knowledge GET before deferred workspace script readiness; yield derivative cache persistence past first render.
- `ca1b459ee9b8702ffd63403abbe143fcaa82e329`: normalize and bind the early GET URL to the mount API identity; discard/abort mismatches.
- `854bb93f68ef0bca0c033c831887702d8b5a4d93`: allow immutable packet readiness on a public direct recorded reference route; no autoplay or earlier fact admission.
- `a83ef2acd71d6cfc47dd61337e2dd0bb6eff7c33`: reuse one lazy UTC timestamp formatter with identical locale/options/output.

Four allowed files changed: autonomous entry/workspace JS and their two existing focused test files. No CSS, index, manifest, backend product changes, seal, fullgate, dependency install, deployment, provider call, production request, or database write.

## Measurements

Single local Chromium sample per matrix cell. Controlled delays/CPU are diagnostics, not measurements of hosted service behavior.

| Knowledge diagnostic | Baseline c925 | Final source a83 |
|---|---:|---:|
| Native first content after DCL | 171.2 ms | 146.6 ms |
| 400 ms workspace + 1390 ms API: GET after DCL | +455.7 ms | −1.8 ms |
| Same controlled cold case: first content after DCL | 1912.1 ms | 1438.5 ms |
| 4×CPU: maximum long task | 219 ms | 172 ms |

The public synthetic projection is exactly 405258 bytes, SHA256 `ab6bc467ac40b8981440e10e71e2c4df27d0f9f005dac3ef66be40f30e771fe8`, derived from 23 heads, not production 26. The entry originally awaited the workspace script before mounting/requesting Knowledge. Cache sizing/canonicalization also ran synchronously before rendering. A later stress spotcheck after cache deferral still reached 207 ms; profiling 26 time labels measured 43.5 ms of repeated formatting setup versus 24.3 ms with formatter reuse. That justified the final narrow formatter follow-up.

| Same 1500 ms API delay on each replay path | Map before → after | First text before → after | First landed before → after | Eighth landed before → after |
|---|---:|---:|---:|---:|
| Direct claim → Choose case → same heating | 51.7 → 60.8 ms | 1825.8 → 395.8 ms | 2519.1 → 1074.8 ms | 14651.9 → 13241.0 ms |
| Direct Demonstration | 70.1 → 68.1 ms | 425.4 → 413.4 ms | 1119.2 → 1116.8 ms | 13185.0 → 13249.5 ms |
| Cases → Demonstration | 40.6 → 36.3 ms | 512.7 → 539.4 ms | 1197.3 → 1215.0 ms | 13313.4 → 13347.6 ms |

All replay runs used the genuine shipped heating packet, its exact decoded 5,420,814-byte operation stream, matching opening/head values and a local GET-only fixture. First 8 landed operation IDs match before/after. Direct entry previously marked the packet ineligible and later restarted through delayed API reads. Keeping speculative readiness available removes that startup gap; first-to-eighth pacing stays about 12.1 seconds. All 3 final replay paths and all 4 final Knowledge cells had no browser errors.

## Verification

- Existing workspace+entry focused suites: 296 passed, 0 failed, 0 skipped, exit 0 (`date-format-suites.log`).
- Final formatter equivalence/laziness checks: 2 passed, 0 failed, 0 skipped, exit 0 (`date-format-focused.log`); one overlaps the 296-suite run and one was added last.
- API mismatch regression fails immutable 1abb, exit 1, then passes the guarded source.
- Direct readiness and cancellation regressions fail before the predicate change, exit 1, then pass.
- `git diff --check` passed; checkout clean after push.
- Initial suite failed only because clone-local Python was absent; `CASEPATH_PYTHON` selected the existing prepared environment and the rerun passed. Nothing was installed.

Exact suite environment and command:

```bash
CASEPATH_PYTHON=/workspace/casepath-release-ae0-shard6/.runtime/casepath-dev-v2/venv/bin/python \
PYTHONDONTWRITEBYTECODE=1 \
TMPDIR=/workspace/knowledge-first-read-20261018/frontend/t \
TMP=/workspace/knowledge-first-read-20261018/frontend/t \
TEMP=/workspace/knowledge-first-read-20261018/frontend/t \
node --test casepath-qa/sites-autonomous-entry.test.cjs casepath-qa/autonomous-workspace-v1.test.cjs
```

Receipts: `receipt.json`, `baseline-browser.json`, `formatter-final-browser.json`, `restart-delayed-baseline.json`, `restart-delayed-candidate.json`. Historical replay receipt labels copied by the first harness were explicitly corrected without changing timing entries; source hashes and correction notes are recorded. The formatter browser receipt records both its checkout base and the final commit matching its captured workspace bytes.

Owned browser/HTTP fixture processes stopped. Evidence scratch is 18 MB; free disk at handoff 3,713,560,576 bytes. Mac owns integration, sealing, hosted/visual acceptance and publication. No further profiling or implementation is pending in this frontend task.

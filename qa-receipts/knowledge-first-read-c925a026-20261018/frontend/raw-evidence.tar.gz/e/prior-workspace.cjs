const Module=require('node:module'),{execFileSync}=require('node:child_process'),path=require('node:path');
const root='/workspace/casepath-knowledge-startup-render-20261018',file=path.join(root,'casepath/assets/autonomous-workspace-v1.js');
const source=execFileSync('git',['show','1abbec801b0e8660ec3f0662fb8ff7ec57fddea0:casepath/assets/autonomous-workspace-v1.js'],{cwd:root,encoding:'utf8',maxBuffer:4*1024*1024});
const m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));m._compile(source,file);require.cache[file]=m;

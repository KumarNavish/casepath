#!/usr/bin/env bash
set -u
cd /workspace/casepath-release-ae0-shard4 || exit 97
env HOME=/workspace/knowledge-read-warm-20261016/review/e/first-request65/home TMPDIR=/workspace/knowledge-read-warm-20261016/review/e/first-request65/tmp TMP=/workspace/knowledge-read-warm-20261016/review/e/first-request65/tmp TEMP=/workspace/knowledge-read-warm-20261016/review/e/first-request65/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspace/casepath-release-ae0-shard4/casepath-api:/workspace/casepath-release-ae0-shard4/casepath-api/tests /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python /workspace/knowledge-read-warm-20261016/review/e/first-request65/perf_diagnose.py > /workspace/knowledge-read-warm-20261016/review/e/first-request65/profile.log 2>&1
profile_exit=$?
printf '%s\n' "$profile_exit" > /workspace/knowledge-read-warm-20261016/review/e/first-request65/exit.txt
cat /workspace/knowledge-read-warm-20261016/review/e/first-request65/profile.log
exit "$profile_exit"

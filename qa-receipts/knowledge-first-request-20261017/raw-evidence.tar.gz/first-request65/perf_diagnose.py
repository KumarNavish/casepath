"""Bounded local diagnosis only; public DTO inputs and an existing tiny Hrana pattern."""
import base64, cProfile, hashlib, io, json, pathlib, platform, pstats, socket, sqlite3, subprocess, sys, time
from collections import Counter
from contextlib import contextmanager
from copy import deepcopy
from importlib.metadata import version

ROOT=pathlib.Path('/workspace/casepath-release-ae0-shard4')
OUT=pathlib.Path('/workspace/knowledge-read-warm-20261016/review/e/first-request65')
PUB=pathlib.Path('/workspace/knowledge-learning-coordinator-20261016/public')
EXPECTED='65a796a5dfb21f4cdbe0a3d1a4925b931710b30c'
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args]).decode().strip()
assert git('rev-parse','HEAD')==EXPECTED and git('status','--porcelain=v1')==''
def snapshot_source():
    return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
        'casepath-api/casepath_api/autonomous_knowledge_v1.py','casepath-api/casepath_api/autonomous_store_v1.py',
        'casepath-api/casepath_api/hosted_storage_v1.py','casepath-api/casepath_api/hosted_app_v1.py',
        'casepath-api/casepath_api/hosted_sql_v1.py','casepath-api/casepath_api/autonomous_api_v1.py')}
source_before=snapshot_source()
import httpx
import casepath_api.autonomous_knowledge_v1 as km
from casepath_api.autonomous_store_v1 import AutonomousStore
from casepath_api.hosted_storage_v1 import HostedAutonomousStore, HostedJournal, HostedSources, JOURNAL_SCHEMA
from hosted_hrana_fixture import MockHrana
from fastapi.encoders import jsonable_encoder
from starlette.responses import JSONResponse

def forbid(*args,**kwargs): raise AssertionError('No network authorized in this local profile')
socket.create_connection=forbid
httpx.HTTPTransport.handle_request=forbid
measurements=[]
def measure(label, fn):
    wall,cpu=time.perf_counter(),time.process_time()
    value=fn()
    measurements.append({'label':label,'wall_ms':(time.perf_counter()-wall)*1000,'cpu_ms':(time.process_time()-cpu)*1000})
    return value

inputs={name:json.loads((PUB/name).read_bytes()) for name in ('knowledge.json','claims.json','knowledge-events.json','knowledge-pins.json')}
claims={row['claim_id']:row for row in inputs['claims.json']['claims']}
states=[]
for cid, head in inputs['knowledge-events.json']['claims'].items():
    state={'claim_id':cid,'title':claims[cid]['title'],'revision':head['current_revision'],
           'last_event_sha256':head['cursor_sha256'],'state_sha256':head['current_state_sha256'],
           'knowledge_published':[],'knowledge_uses':[],'events':[],
           'semantic_contexts':inputs['knowledge-pins.json']['claims'].get(cid,{}).get('semantic_contexts',{})}
    for event in head['events']:
        assert event['kind'] in ('knowledge.published','knowledge.used')
        state['knowledge_published' if event['kind']=='knowledge.published' else 'knowledge_uses'].append(event['payload']['knowledge'])
        state['events'].append({key:event[key] for key in ('kind','created_at','sequence','event_sha256','command_sha256','idempotency_key')})
    states.append(state)
states.sort(key=lambda row:row['claim_id'])
class PublicDTO:
    """Already exported compact inputs; this does NOT validate native journal/source authority."""
    def knowledge_snapshot(self): return deepcopy(states)
public_knowledge=km.AutonomousKnowledge(PublicDTO(),{})
public_startup=measure('public_dto_startup_learning_view',public_knowledge.learning_view)
existing=json.loads((PUB.parent/'projection-6064.json').read_bytes())
comparison={k:public_startup.get(k)==existing.get(k) for k in ('versions','uses','quarantined','learning_replay')}
project_counter=Counter()
original_project=public_knowledge._project
original_learning=km._learning_replay
def count_project(*args,**kwargs):
    project_counter['project']+=1
    return original_project(*args,**kwargs)
def count_learning(*args,**kwargs):
    project_counter['learning_replay']+=1
    return original_learning(*args,**kwargs)
public_knowledge._project=count_project
km._learning_replay=count_learning
public_outputs=[]
for i in range(6):
    payload=measure('public_first_after_startup_view' if i==0 else f'public_repeat_{i}_view',public_knowledge.learning_view)
    assert payload==public_startup
    encoded=measure('public_first_fastapi_jsonable_encoder' if i==0 else f'public_repeat_{i}_fastapi_jsonable_encoder',lambda:jsonable_encoder(payload))
    response=measure('public_first_starlette_json_render' if i==0 else f'public_repeat_{i}_starlette_json_render',lambda:JSONResponse(encoded))
    public_outputs.append(len(response.body))
public_poststartup_counts=dict(project_counter)
km._learning_replay=original_learning

class CountedHrana(MockHrana):
    def __init__(self,path):
        super().__init__(path)
        self.wire_bytes=[]
    def handle(self, request):
        result=super().handle(request)
        self.wire_bytes.append(len(result.content))
        return result
    def reset(self): self.requests.clear(); self.wire_bytes.clear()

scratch=OUT/'tmp'/'native';scratch.mkdir(parents=True,exist_ok=True)
class LocalJournal:
    # Use the store's supported journal injection with the existing Hrana schema;
    # avoids importing unrelated controller/model dependencies from ClaimLoopStore.
    def __init__(self,path):
        self.path=path
        with sqlite3.connect(path) as db:db.executescript(JOURNAL_SCHEMA)
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path)
        db.row_factory=sqlite3.Row
        try:
            with db:yield db
        finally:db.close()
native=AutonomousStore(scratch/'native.sqlite3',journal=LocalJournal(scratch/'native.sqlite3'))
original_file=b'Isolated synthetic original attachment.\n'*7500
for index in range(2):
    native.intake({'title':f'Native proof fixture {index}','message':f'Original statement {index}. '*500,
       'files':[{'file_name':'original.txt','media_type':'text/plain','content_base64':base64.b64encode(original_file).decode()}]},f'proof.intake.{index}')
server=CountedHrana(scratch/'hosted.sqlite3')
journal=HostedJournal(scratch/'unused',server.connection)
with sqlite3.connect(native.path) as source,sqlite3.connect(server.path) as target:
    target.executemany('INSERT INTO claim_loop_events VALUES (?,?,?,?,?,?,?,?)',source.execute('SELECT * FROM claim_loop_events').fetchall())
    for path in native.source_root.iterdir():
        raw=path.read_bytes()
        target.executemany('INSERT INTO autonomous_source_chunks VALUES (?,?,?)',[(path.name,index,raw[offset:offset+HostedSources.CHUNK_BYTES]) for index,offset in enumerate(range(0,len(raw),HostedSources.CHUNK_BYTES))])
store=HostedAutonomousStore(journal.path,journal=journal,source_store=HostedSources(server.connection))
knowledge=km.AutonomousKnowledge(store,{})
timed={}
def attach(obj,name,label=None):
    original=getattr(obj,name)
    label=label or name
    def run(*args,**kwargs):
        entry=timed.setdefault(label,{'calls':0,'wall_ms':0.0,'cpu_ms':0.0})
        entry['calls']+=1
        wall,cpu=time.perf_counter(),time.process_time()
        try:return original(*args,**kwargs)
        finally:
            entry['wall_ms']+=(time.perf_counter()-wall)*1000
            entry['cpu_ms']+=(time.process_time()-cpu)*1000
    setattr(obj,name,run)
for name in ('knowledge_snapshot','_knowledge_rows','_validated_knowledge_states','_after_validated_knowledge_states','_replay','_validate_descriptor'): attach(store,name)
for name in ('prefetch_journal_sources','_knowledge_source_proof','verify_knowledge_many'): attach(store._source_store,name)
attach(knowledge,'_project')
attach(km,'_learning_replay')
native_reads=[]
try:
    for i in range(7):
        timed.clear();server.reset()
        value=measure('tiny_native_startup' if i==0 else 'tiny_native_first_after_startup' if i==1 else f'tiny_native_repeat_{i-1}',knowledge.learning_view)
        if i==0:expected_native=value
        else:assert value==expected_native
        commands=[op.get('stmt',{}).get('sql','') for request in server.requests for op in request['requests']]
        native_reads.append({'phase':'startup' if i==0 else 'first_after_startup' if i==1 else f'repeat_{i-1}',
             'request_count':len(server.requests),'wire_bytes':sum(server.wire_bytes),
             'raw_journal_select_count':sum('CROSS JOIN claim_loop_events AS j' in sql for sql in commands),
             'raw_source_select_count':sum(sql.startswith('SELECT sha256,chunk_index') for sql in commands),
             'methods':deepcopy(timed)})
    prof=cProfile.Profile();prof.enable();knowledge.learning_view();prof.disable()
    buff=io.StringIO();pstats.Stats(prof,stream=buff).sort_stats('cumulative').print_stats(35)
    (OUT/'tiny-native-warm-cprofile.txt').write_text(buff.getvalue())
    fixture_metadata={'claim_states':len(expected_native['learning_replay']['journal_heads']),
          'versions':len(expected_native['versions']),'uses':len(expected_native['uses']),
          'journal_rows':sqlite3.connect(server.path).execute('SELECT count(*) FROM claim_loop_events').fetchone()[0],
          'source_bytes':sum(p.stat().st_size for p in native.source_root.iterdir())}
finally: server.close()
source_after=snapshot_source()
assert source_after==source_before and git('status','--porcelain=v1')=='' and git('rev-parse','HEAD')==EXPECTED
report={'commit':EXPECTED,'execution':'managed Cloud Linux; no network/production/credentials',
 'python':sys.version,'dependency_versions':{name:version(name) for name in ('httpx','fastapi','starlette')},
 'public_dto':{'input_claims':len(claims),'learning_head_states':len(states),
       'learning_events':len(public_startup['learning_replay']['events']),
       'versions':len(public_startup['versions']),'uses':len(public_startup['uses']),
       'exact_projection_6064_comparison':comparison,'serialized_bytes_each_run':public_outputs,
       'poststartup_project_learning_calls':public_poststartup_counts,
       'inputs_sha256':{name:hashlib.sha256((PUB/name).read_bytes()).hexdigest() for name in inputs}},
 'tiny_native_fixture':fixture_metadata,'measurements':measurements,'native_reads':native_reads,
 'source_clean_and_pre_post_hashes_equal':True,'source_sha256':source_before,
 'limits':['Public DTO profile excludes native journal/source validation; filtered 23-head snapshot cannot establish complete26-head/633-row current authority.',
           'Native proof profile uses only2intake journal rows with no knowledge publications/uses; it proves request/function behavior, not current production CPU/performance.',
           'Prepared gate venv retired; reused existing /opt Python3.12 and installed deps, not pinned app runtime. All timing is local Linux CPU/SQLite/MockTransport, not native Mac/cloud API latency.',
           'No real sockets/TLS/proxy/network timings; profile overhead for the separate cProfile run is not mixed into unprofiled timings.']}
(OUT/'profile.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'public_dto':report['public_dto'],'native_fixture':fixture_metadata,'measurements':measurements,
                 'native_request_counts':[row['request_count'] for row in native_reads]},indent=2))

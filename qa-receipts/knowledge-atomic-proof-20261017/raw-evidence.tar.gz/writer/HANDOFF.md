Backend atomic warm proof handoff

Base: 65a796a5dfb21f4cdbe0a3d1a4925b931710b30c
Final branch: codex/knowledge-atomic-proof-20261017
Final commit: cb648a3e8a7c5ef3605f25273afc14c3a247d52b
Implementation commit: 278868c64fcdf952360e821a9d6038027e353aec
The final followup is test-only. Source scope and exact hashes: SOURCE-RECEIPT.json.

120 focused tests pass (59 authority-proof tests; 61 source/Knowledge tests).
Independent review: /workspace/atomic-proof-20261017/review/e/REVIEW-cb648a3e.json.
Matched baseline/candidate: startup 31 requests in both; each first/repeat warm
read 2 requests/7602 response bytes -> 1 request/7274 bytes. Every decoded result
and 136307-byte UTF8 JSON is identical. No warm replay/project/learning rebuild.
The measurement uses an 18-processed-claim synthetic fixture and SQLite-backed
MockHrana, and establishes request reduction rather than production latency.

Native adapter requirement

The final combined certificate is permitted only when journal.connect and
sources.connect are the same exact callable object, or genuine types.MethodType
objects whose __self__ and __func__ are identical. Two unrelated lambda/wrapper
functions do not qualify even if they eventually connect to the same endpoint.
Use the same existing native adapter instance's bound connect method for both
components, or capture one exact callable once and pass it to both. Preserve its
read-only behavior, proxy/CA, request/byte/time limits, and close ownership.
Production already uses the same HostedWorkflowLease instance's lease.connect.
The connection returned by that factory must support read_snapshot.

Do not instantiate HostedJournal on a production connection merely for probing:
its constructor creates schema. Use the already-authorized read-only native probe
and its journal adapter. After startup validation, warm learning_view() should
have one read_snapshot with 2 journal SELECTs + 1 source-schema SELECT + one complete
source proof SELECT per batch (at most 125 batches), followed by confirmed COMMIT
and close. Unknown factory ownership, absent caches/bytes, or 126 source batches
must retain the existing separate proof path. Uncertain operations do not retry.

Exact focused command from the worker checkout

```bash
export TMPDIR=/workspace/atomic-proof-20261017/writer/t TMP=/workspace/atomic-proof-20261017/writer/t TEMP=/workspace/atomic-proof-20261017/writer/t
HOME=/workspace/atomic-proof-20261017/writer/home PYTHONPATH=casepath-api PYTHONDONTWRITEBYTECODE=1 .runtime/casepath-dev-v2/venv/bin/python -m pytest -q casepath-api/tests/test_hosted_knowledge_warm_proof_v1.py --basetemp=/workspace/atomic-proof-20261017/writer/t/proof-final
HOME=/workspace/atomic-proof-20261017/writer/home PYTHONPATH=casepath-api PYTHONDONTWRITEBYTECODE=1 .runtime/casepath-dev-v2/venv/bin/python -m pytest -q -s casepath-api/tests/test_hosted_source_batch_v1.py casepath-api/tests/test_autonomous_knowledge_reads_v1.py --basetemp=/workspace/atomic-proof-20261017/writer/t/reads
```

Fresh disposable --basetemp paths are required for reruns. The source suite ran
before the final test-only commit; implementation is identical. Exact commands,
outcomes and earlier failures are retained in QA-atomic-proof.json and logs.

Preserved failures

prepare-clean65.log: default inherited uv cache was read-only; rerun with existing
writable cache/Python paths succeeded without changing source or verification.
red.log: 3 intended preimplementation failures, including journal mutation after
local descriptor validation. green.log: those 3 pass after implementation.
proof-initial.log: 44 pass/2 fail exposed journal-schema fallback reusing the cached
certificate; implementation now discards that journal candidate before raw path.
proof-second.log: 46 pass; proof-expanded.log: 59 pass at final source.
measurement-baseline.log:initial evidence harness counted module-level
_learning_replay as an instance method; corrected harness only, successful matched
logs/JSON retained. No product change was needed for this evidence failure.

Limits

No production data/network/credentials, full suite, gate, source seal, deployment,
or integration branch advance. Clean65a prepare capsule is retained; focused tests
execute authored worker source using its pinned Python 3.13.9. Mac owns final
integration, source sealing, native production measurements and release gates.

Export safety

This e/ subtree contains only allowlisted receipts, source hashes, deterministic
test logs, measurement scripts and baseline source modules. It contains no DB,
runtime/home, environment snapshot, credentials, original source data, or live
service state. EXPORT-MANIFEST.json records every exported file and its hash.

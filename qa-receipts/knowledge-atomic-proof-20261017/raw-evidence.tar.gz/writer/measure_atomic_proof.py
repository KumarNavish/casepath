"""Matched exact65a/candidate deterministic fixture measurement; no sockets."""
from pathlib import Path
import importlib.util
import json
from hashlib import sha256
import sys
from time import perf_counter

repo = Path('/workspace/casepath-release-ae0-shard6')
artifacts = Path('/workspace/atomic-proof-20261017/writer/artifacts')
sys.path[:0] = [str(repo / 'casepath-api'), str(repo / 'casepath-api/tests')]
mode = sys.argv[1]
if mode == 'baseline':
    for name in ('autonomous_store_v1', 'hosted_storage_v1'):
        qualified = 'casepath_api.' + name
        spec = importlib.util.spec_from_file_location(qualified, artifacts / ('baseline_' + name + '.py'))
        module = importlib.util.module_from_spec(spec)
        sys.modules[qualified] = module
        spec.loader.exec_module(module)

import httpx
from casepath_api.autonomous_knowledge_v1 import AutonomousKnowledge
from casepath_api import autonomous_knowledge_v1 as knowledge_module
from casepath_api.autonomous_store_v1 import AutonomousStore
from casepath_api.workspace_corpus import PublicCorpus, default_workspace_corpus_root
from test_autonomous_knowledge_reads_v1 import hosted_copy

def no_network(*args, **kwargs):
    raise AssertionError('Unexpected real network dispatch')

httpx.HTTPTransport.handle_request = no_network
root = artifacts / ('matched-' + mode + '-final')
root.mkdir()
original = Path('/workspace/atomic-proof-20261017/writer/t/reads/knowledge-processed-roster0/claims.sqlite3')
policy = PublicCorpus(default_workspace_corpus_root()).static_policy()
native = AutonomousStore.open_read_only(original)
expected = AutonomousKnowledge(native, policy).learning_view()
expected_bytes = json.dumps(expected, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
server, store, _, _ = hosted_copy((original, native.source_root, policy, None), root)
knowledge = AutonomousKnowledge(store, policy)
counts = {'_replay': 0, '_project': 0, '_learning_replay': 0}

def count(owner, name):
    method = getattr(owner, name)
    def wrapped(*args, **kwargs):
        counts[name] += 1
        return method(*args, **kwargs)
    setattr(owner, name, wrapped)

count(store, '_replay')
count(knowledge, '_project')
count(knowledge_module, '_learning_replay')
measurements = []
try:
    for phase in ('startup', 'first_poststartup', 'repeat_1', 'repeat_2'):
        server.reset_counts()
        before = dict(counts)
        started = perf_counter()
        value = knowledge.learning_view()
        elapsed = perf_counter() - started
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        assert value == expected and raw == expected_bytes
        queries = [[operation.get('stmt', {}).get('sql', '') for operation in request['requests']]
                   for request in server.requests]
        assert all(query.split()[0] in {'SELECT', 'BEGIN', 'COMMIT'} for request in queries for query in request if query)
        measurements.append({'phase': phase, 'http_requests': len(server.requests),
            'response_bytes': sum(server.response_bytes), 'raw_journal_pages': len(server.journal_pages),
            'raw_source_selects': sum(sql.startswith('SELECT sha256,chunk_index') for request in queries for sql in request),
            'selects_per_request': [sum(sql.startswith('SELECT') for sql in request) for request in queries],
            'calls': {name: counts[name] - before[name] for name in counts},
            'fixture_wall_seconds': round(elapsed, 6), 'decoded_and_utf8_identity': True,
            'payload_sha256': sha256(raw).hexdigest(), 'payload_bytes': len(raw), 'open_streams': server.open_streams})
        assert server.open_streams == 0
    result = {'mode': mode, 'base': '65a796a5dfb21f4cdbe0a3d1a4925b931710b30c',
              'candidate': 'cb648a3e8a7c5ef3605f25273afc14c3a247d52b',
              'fixture_claims': len(expected['learning_replay']['journal_heads']),
              'fixture_only_no_real_socket_or_production_data': True, 'measurements': measurements}
    (artifacts / ('measurement-' + mode + '.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
finally:
    server.close()

#!/usr/bin/env bash
set -u
cd /workspace/casepath-release-ae0-shard4 || exit 97
env HOME=/workspace/atomic-proof-20261017/review/home TMPDIR=/workspace/atomic-proof-20261017/review/tmp TMP=/workspace/atomic-proof-20261017/review/tmp TEMP=/workspace/atomic-proof-20261017/review/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspace/casepath-release-ae0-shard4/casepath-api:/workspace/casepath-release-ae0-shard4/casepath-api/tests /workspace/casepath-release-ae0-shard6/.runtime/casepath-dev-v2/venv/bin/python -m pytest -p no:cacheprovider -q casepath-api/tests/test_hosted_source_batch_v1.py::test_knowledge_final_source_verification_still_detects_mutation_after_prefetch casepath-api/tests/test_hosted_source_batch_v1.py::test_final_boundary_rechecks_bytes_changed_after_cold_prefetch --basetemp=/workspace/atomic-proof-20261017/review/tmp/final-boundary-2788 --junitxml=/workspace/atomic-proof-20261017/review/e/final-boundary-2788.xml > /workspace/atomic-proof-20261017/review/e/final-boundary-2788.log 2>&1
final_boundary_exit=$?
printf '%s\n' "$final_boundary_exit" > /workspace/atomic-proof-20261017/review/e/final-boundary-2788-exit.txt
cat /workspace/atomic-proof-20261017/review/e/final-boundary-2788.log
exit "$final_boundary_exit"

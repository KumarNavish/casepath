#!/usr/bin/env bash
set -u
cd /workspace/casepath-release-ae0-shard4 || exit 97
env HOME=/workspace/atomic-proof-20261017/review/home TMPDIR=/workspace/atomic-proof-20261017/review/tmp TMP=/workspace/atomic-proof-20261017/review/tmp TEMP=/workspace/atomic-proof-20261017/review/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspace/casepath-release-ae0-shard4/casepath-api:/workspace/casepath-release-ae0-shard4/casepath-api/tests /workspace/casepath-release-ae0-shard6/.runtime/casepath-dev-v2/venv/bin/python -m pytest -p no:cacheprovider -q casepath-api/tests/test_hosted_knowledge_warm_proof_v1.py -k 'separate_source_primary or unproven_factory_wrapper or final_atomic_aggregate_malformation or cancelled_final_atomic or missing_admitted_candidate or combined_select_budget or preserves_every_source_identity' --basetemp=/workspace/atomic-proof-20261017/review/tmp/followup-cb64 --junitxml=/workspace/atomic-proof-20261017/review/e/followup-cb64.xml > /workspace/atomic-proof-20261017/review/e/followup-cb64.log 2>&1
followup_exit=$?
printf '%s\n' "$followup_exit" > /workspace/atomic-proof-20261017/review/e/followup-cb64-exit.txt
cat /workspace/atomic-proof-20261017/review/e/followup-cb64.log
exit "$followup_exit"

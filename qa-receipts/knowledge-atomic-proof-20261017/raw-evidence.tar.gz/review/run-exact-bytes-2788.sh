#!/usr/bin/env bash
set -u
cd /workspace/casepath-release-ae0-shard4 || exit 97
env HOME=/workspace/atomic-proof-20261017/review/home TMPDIR=/workspace/atomic-proof-20261017/review/tmp TMP=/workspace/atomic-proof-20261017/review/tmp TEMP=/workspace/atomic-proof-20261017/review/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspace/casepath-release-ae0-shard4/casepath-api:/workspace/casepath-release-ae0-shard4/casepath-api/tests /workspace/casepath-release-ae0-shard6/.runtime/casepath-dev-v2/venv/bin/python -m pytest -p no:cacheprovider -q /workspace/atomic-proof-20261017/review/e/test_independent_atomic_proof.py::test_exact_hit_one_closed_transaction_copies_all_output_and_preserves_originals --basetemp=/workspace/atomic-proof-20261017/review/tmp/exact-bytes-2788 --junitxml=/workspace/atomic-proof-20261017/review/e/exact-bytes-2788.xml > /workspace/atomic-proof-20261017/review/e/exact-bytes-2788.log 2>&1
exact_bytes_exit=$?
printf '%s\n' "$exact_bytes_exit" > /workspace/atomic-proof-20261017/review/e/exact-bytes-2788-exit.txt
cat /workspace/atomic-proof-20261017/review/e/exact-bytes-2788.log
exit "$exact_bytes_exit"

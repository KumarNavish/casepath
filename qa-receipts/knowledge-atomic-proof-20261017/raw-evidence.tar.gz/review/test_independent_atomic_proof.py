"""Independent adversarial checks; only disposable native fixtures/MockTransport."""
import json
import base64
import sqlite3
from copy import deepcopy

import pytest
from hosted_hrana_fixture import MockHrana
from test_hosted_knowledge_warm_proof_v1 import native_proof_store
from casepath_api.autonomous_knowledge_v1 import AutonomousKnowledge
from casepath_api.autonomous_store_v1 import AutonomousStoreError
from casepath_api.hosted_storage_v1 import HostedAutonomousStore, HostedSources


def commands(request):
    payload = request if isinstance(request, dict) else json.loads(request.content)
    return [item.get('stmt', {}).get('sql', '') for item in payload['requests']]


def domains(request):
    statements = commands(request)
    return {domain for domain in ('journal', 'source')
            if any('casepath-' + domain + '-bytes-v1:set:' in sql for sql in statements)}


def alter_source_preserving_schema(path):
    with sqlite3.connect(path) as db:
        triggers = db.execute("SELECT name,sql FROM sqlite_schema WHERE type='trigger' AND tbl_name='autonomous_source_chunks'").fetchall()
        for name, _ in triggers:
            db.execute('DROP TRIGGER "' + name.replace('"', '""') + '"')
        digest, index = db.execute('SELECT sha256,chunk_index FROM autonomous_source_chunks ORDER BY sha256,chunk_index LIMIT 1').fetchone()
        db.execute('UPDATE autonomous_source_chunks SET content=? WHERE sha256=? AND chunk_index=?',
                   (b'Unaccepted changed original bytes.', digest, index))
        for _, sql in triggers:
            db.execute(sql)


def test_exact_hit_one_closed_transaction_copies_all_output_and_preserves_originals(native_proof_store):
    server, store, knowledge = native_proof_store
    expected = deepcopy(knowledge.learning_view())
    expected_bytes = json.dumps(expected, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()
    with sqlite3.connect(server.path) as db:
        before_journal = db.execute('SELECT * FROM claim_loop_events ORDER BY loop_id,sequence').fetchall()
        before_sources = db.execute('SELECT * FROM autonomous_source_chunks ORDER BY sha256,chunk_index').fetchall()
    for _ in range(2):
        server.reset()
        result = knowledge.learning_view()
        assert result == expected
        assert json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode() == expected_bytes
        assert len(server.requests) == 1
        payload, = server.requests
        assert domains(payload) == {'journal', 'source'}
        operations = payload['requests']
        assert operations[0]['stmt']['sql'] == 'BEGIN'
        assert operations[-2]['stmt']['sql'] == 'COMMIT'
        assert operations[-1] == {'type': 'close'}
        assert all(item['stmt']['sql'].startswith('SELECT') for item in operations[1:-2])
        assert not server.raw_journal and not server.raw_sources and server.open_streams == 0
        result['learning_replay']['journal_heads'][0]['revision'] = -1
        result['uses'].append({'caller_only': True})
    with sqlite3.connect(server.path) as db:
        assert db.execute('SELECT * FROM claim_loop_events ORDER BY loop_id,sequence').fetchall() == before_journal
        assert db.execute('SELECT * FROM autonomous_source_chunks ORDER BY sha256,chunk_index').fetchall() == before_sources


@pytest.mark.parametrize('changed_domain', ['journal', 'source'])
def test_remote_change_after_local_validation_before_final_combined_snapshot_is_rejected(native_proof_store, monkeypatch, changed_domain):
    server, _, knowledge = native_proof_store
    knowledge.learning_view()
    handle, changed = server.handle, []
    def mutate_at_final_request(request):
        if domains(request) == {'journal', 'source'} and not changed:
            changed.append(True)
            if changed_domain == 'source':
                alter_source_preserving_schema(server.path)
            else:
                with sqlite3.connect(server.path) as db:
                    db.execute("UPDATE claim_loop_events SET created_at='Unaccepted final-boundary timestamp' WHERE rowid=(SELECT min(rowid) FROM claim_loop_events)")
        return handle(request)
    monkeypatch.setattr(server, 'handle', mutate_at_final_request)
    server.reset()
    with pytest.raises(AutonomousStoreError):
        knowledge.learning_view()
    assert changed == [True]
    assert domains(server.requests[0]) == {'journal', 'source'}
    assert server.open_streams == 0


@pytest.mark.parametrize('changed_domain', ['journal', 'source'])
@pytest.mark.parametrize('fault', ['malformed_root', 'truncated_count'])
def test_no_domain_can_return_cached_projection_on_malformed_final_proof(native_proof_store, monkeypatch, changed_domain, fault):
    server, _, knowledge = native_proof_store
    knowledge.learning_view()
    statement, changed = server._statement, []
    def corrupt_proof(connection, command):
        result = statement(connection, command)
        if 'casepath-' + changed_domain + '-bytes-v1:set:' in command['sql']:
            changed.append(True)
            names = [col['name'] for col in result['cols']]
            key, value = ('root', 'abc') if fault == 'malformed_root' else ('concat_bytes', 0)
            result['rows'][0][names.index(key)] = server._value(value)
        return result
    monkeypatch.setattr(server, '_statement', corrupt_proof)
    server.reset()
    with pytest.raises(AutonomousStoreError, match='malformed|truncated'):
        knowledge.learning_view()
    assert changed == [True]
    assert len(server.requests) == 1  # Malformed/uncertain outcome is not a cache miss/retry.
    assert domains(server.requests[0]) == {'journal', 'source'}
    assert server.open_streams == 0


def test_each_source_batch_is_in_the_same_final_snapshot(native_proof_store, monkeypatch):
    server, store, knowledge = native_proof_store
    expected = knowledge.learning_view()
    sources = store._source_store
    monkeypatch.setattr(sources, 'BATCH_DIGESTS', 1)
    server.reset()
    assert knowledge.learning_view() == expected
    assert len(server.requests) == 1
    statements = commands(server.requests[0])
    assert sum('casepath-source-bytes-v1:set:' in sql for sql in statements) == len(sources._cache)
    assert sum('casepath-journal-bytes-v1:set:' in sql for sql in statements) == 1
    assert len(statements[1:-2]) <= 128
    assert not server.raw_journal and not server.raw_sources


def test_identical_lookalike_journal_db_cannot_certify_an_independent_source_primary(native_proof_store, tmp_path):
    journal_server, original_store, _ = native_proof_store
    source_server = MockHrana(tmp_path / 'independent-source-primary.sqlite3')
    with sqlite3.connect(journal_server.path) as source, sqlite3.connect(source_server.path) as target:
        source.backup(target)
    store = HostedAutonomousStore(original_store.path, journal=original_store.journal,
                                  source_store=HostedSources(source_server.connection))
    knowledge = AutonomousKnowledge(store, {})
    try:
        expected = knowledge.learning_view()
        journal_server.reset()
        source_server.requests.clear()
        assert knowledge.learning_view() == expected
        assert len(journal_server.requests) == 1 and len(source_server.requests) == 1
        assert domains(journal_server.requests[0]) == {'journal'}
        assert domains(source_server.requests[0]) == {'source'}
        alter_source_preserving_schema(source_server.path)
        journal_server.reset()
        source_server.requests.clear()
        with pytest.raises(AutonomousStoreError, match='source|bytes|hash|chunk'):
            knowledge.learning_view()
        assert source_server.requests
        assert all(domains(request) != {'journal', 'source'} for request in journal_server.requests)
    finally:
        source_server.close()


def test_unprovable_distinct_wrapper_factories_conservatively_use_separate_proofs(native_proof_store):
    server, original_store, _ = native_proof_store
    def journal_connect(): return server.connection()
    def source_connect(): return server.connection()
    from casepath_api.hosted_storage_v1 import HostedJournal
    journal = HostedJournal(original_store.path, journal_connect)
    store = HostedAutonomousStore(journal.path, journal=journal, source_store=HostedSources(source_connect))
    knowledge = AutonomousKnowledge(store, {})
    expected = knowledge.learning_view()
    server.reset()
    assert knowledge.learning_view() == expected
    assert len(server.requests) == 2
    assert [domains(request) for request in server.requests] == [{'journal'}, {'source'}]


def test_over_combined_query_budget_keeps_existing_separate_snapshot_bounds(native_proof_store, monkeypatch):
    server, store, knowledge = native_proof_store
    # Six valid native intakes, each with twenty distinct tiny attachments and
    # one distinct message, produce126 referenced source digests without any
    # large bodies. Single-digest proof batches would require129 combined
    # SELECTs; the original source-only request needs127 and remains valid.
    with sqlite3.connect(server.path) as db:
        db.execute('DELETE FROM claim_loop_events')
    for claim in range(6):
        files = [{'file_name': f'part-{claim}-{index}.txt', 'media_type': 'text/plain',
                  'content_base64': base64.b64encode(f'Original public fixture {claim}/{index}.'.encode()).decode()}
                 for index in range(20)]
        store.intake({'title': f'Bounded126-source fixture {claim}',
                      'message': f'Unique original message for bounded claim {claim}.', 'files': files},
                     f'independent.budget.{claim}')
    expected = knowledge.learning_view()
    assert len(expected['learning_replay']['journal_heads']) == 6
    monkeypatch.setattr(store._source_store, 'BATCH_DIGESTS', 1)
    server.reset()
    assert knowledge.learning_view() == expected
    assert len(server.requests) == 2
    assert [domains(request) for request in server.requests] == [{'journal'}, {'source'}]
    selects = [commands(request)[1:-2] for request in server.requests]
    assert [len(value) for value in selects] == [2, 127]
    assert all(len(value) <= 128 for value in selects)
    assert not server.raw_journal and not server.raw_sources and server.open_streams == 0

#!/usr/bin/env bash
set -u
cd /workspace/casepath-release-ae0-shard4 || exit 97
git rev-parse HEAD > /workspace/atomic-proof-20261017/review/e/source-before-2788.txt
git status --porcelain=v1 >> /workspace/atomic-proof-20261017/review/e/source-before-2788.txt
sha256sum casepath-api/casepath_api/autonomous_store_v1.py casepath-api/casepath_api/hosted_storage_v1.py casepath-api/tests/test_hosted_knowledge_warm_proof_v1.py >> /workspace/atomic-proof-20261017/review/e/source-before-2788.txt
env HOME=/workspace/atomic-proof-20261017/review/home TMPDIR=/workspace/atomic-proof-20261017/review/tmp TMP=/workspace/atomic-proof-20261017/review/tmp TEMP=/workspace/atomic-proof-20261017/review/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspace/casepath-release-ae0-shard4/casepath-api:/workspace/casepath-release-ae0-shard4/casepath-api/tests /workspace/casepath-release-ae0-shard6/.runtime/casepath-dev-v2/venv/bin/python -m pytest -p no:cacheprovider -q casepath-api/tests/test_hosted_knowledge_warm_proof_v1.py /workspace/atomic-proof-20261017/review/e/test_independent_atomic_proof.py --basetemp=/workspace/atomic-proof-20261017/review/tmp/pytest-2788 --junitxml=/workspace/atomic-proof-20261017/review/e/independent-2788.xml > /workspace/atomic-proof-20261017/review/e/independent-2788.log 2>&1
independent_exit=$?
printf '%s\n' "$independent_exit" > /workspace/atomic-proof-20261017/review/e/independent-2788-exit.txt
git rev-parse HEAD > /workspace/atomic-proof-20261017/review/e/source-after-2788.txt
git status --porcelain=v1 >> /workspace/atomic-proof-20261017/review/e/source-after-2788.txt
sha256sum casepath-api/casepath_api/autonomous_store_v1.py casepath-api/casepath_api/hosted_storage_v1.py casepath-api/tests/test_hosted_knowledge_warm_proof_v1.py >> /workspace/atomic-proof-20261017/review/e/source-after-2788.txt
du -sb /workspace/atomic-proof-20261017/review/home /workspace/atomic-proof-20261017/review/tmp > /workspace/atomic-proof-20261017/review/e/scratch-2788.txt
cat /workspace/atomic-proof-20261017/review/e/independent-2788.log
exit "$independent_exit"

# CasePath submission source

Compile main.tex with XeLaTeX and BibTeX, or with Tectonic.
The submitted title and abstract are preserved. Measurement provenance,
figure generators and offline reproduction are in the companion archive.
